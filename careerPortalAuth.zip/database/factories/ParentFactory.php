<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Parent;
use Faker\Generator as Faker;

$factory->define(Parent::class, function (Faker $faker) {
    return [
        //
    ];
});
