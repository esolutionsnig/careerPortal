<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Prent;
use Faker\Generator as Faker;

$factory->define(Prent::class, function (Faker $faker) {
    return [
        //
    ];
});
