<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Fullselfdisclosure;
use Faker\Generator as Faker;

$factory->define(Fullselfdisclosure::class, function (Faker $faker) {
    return [
        //
    ];
});
