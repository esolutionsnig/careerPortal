<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Schoolleavingcertificate;
use Faker\Generator as Faker;

$factory->define(Schoolleavingcertificate::class, function (Faker $faker) {
    return [
        //
    ];
});
