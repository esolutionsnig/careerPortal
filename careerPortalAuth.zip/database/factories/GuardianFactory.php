<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Guardian;
use Faker\Generator as Faker;

$factory->define(Guardian::class, function (Faker $faker) {
    return [
        //
    ];
});
