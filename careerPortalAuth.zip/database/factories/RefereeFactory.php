<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Referee;
use Faker\Generator as Faker;

$factory->define(Referee::class, function (Faker $faker) {
    return [
        //
    ];
});
