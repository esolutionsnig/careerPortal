<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Employmentselfassessment;
use Faker\Generator as Faker;

$factory->define(Employmentselfassessment::class, function (Faker $faker) {
    return [
        //
    ];
});
