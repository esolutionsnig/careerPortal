<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Nationalservice;
use Faker\Generator as Faker;

$factory->define(Nationalservice::class, function (Faker $faker) {
    return [
        //
    ];
});
