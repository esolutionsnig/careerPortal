<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Socialmembership;
use Faker\Generator as Faker;

$factory->define(Socialmembership::class, function (Faker $faker) {
    return [
        //
    ];
});
