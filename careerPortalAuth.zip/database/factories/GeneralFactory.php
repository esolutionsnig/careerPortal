<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\General;
use Faker\Generator as Faker;

$factory->define(General::class, function (Faker $faker) {
    return [
        //
    ];
});
