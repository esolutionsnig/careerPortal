<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Bankingdetail;
use Faker\Generator as Faker;

$factory->define(Bankingdetail::class, function (Faker $faker) {
    return [
        //
    ];
});
