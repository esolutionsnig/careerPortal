<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Dependant;
use Faker\Generator as Faker;

$factory->define(Dependant::class, function (Faker $faker) {
    return [
        //
    ];
});
