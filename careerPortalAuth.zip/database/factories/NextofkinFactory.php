<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Nextofkin;
use Faker\Generator as Faker;

$factory->define(Nextofkin::class, function (Faker $faker) {
    return [
        //
    ];
});
