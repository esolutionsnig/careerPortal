<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Hometownaddress;
use Faker\Generator as Faker;

$factory->define(Hometownaddress::class, function (Faker $faker) {
    return [
        //
    ];
});
