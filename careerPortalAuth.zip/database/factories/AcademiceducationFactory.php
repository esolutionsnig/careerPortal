<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Academiceducation;
use Faker\Generator as Faker;

$factory->define(Academiceducation::class, function (Faker $faker) {
    return [
        //
    ];
});
