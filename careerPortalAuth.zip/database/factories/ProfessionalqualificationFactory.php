<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Professionalqualification;
use Faker\Generator as Faker;

$factory->define(Professionalqualification::class, function (Faker $faker) {
    return [
        //
    ];
});
