<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Applicantdatamanager;
use Faker\Generator as Faker;

$factory->define(Applicantdatamanager::class, function (Faker $faker) {
    return [
        //
    ];
});
