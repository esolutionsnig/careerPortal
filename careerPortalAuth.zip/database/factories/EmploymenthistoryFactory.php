<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Employmenthistory;
use Faker\Generator as Faker;

$factory->define(Employmenthistory::class, function (Faker $faker) {
    return [
        //
    ];
});
