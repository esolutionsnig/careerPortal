<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Professionalmembership;
use Faker\Generator as Faker;

$factory->define(Professionalmembership::class, function (Faker $faker) {
    return [
        //
    ];
});
