<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Parents;
use Faker\Generator as Faker;

$factory->define(Parents::class, function (Faker $faker) {
    return [
        //
    ];
});
