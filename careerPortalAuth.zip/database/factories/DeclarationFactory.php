<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Declaration;
use Faker\Generator as Faker;

$factory->define(Declaration::class, function (Faker $faker) {
    return [
        //
    ];
});
