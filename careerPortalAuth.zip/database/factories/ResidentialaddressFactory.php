<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Model\Residentialaddress;
use Faker\Generator as Faker;

$factory->define(Residentialaddress::class, function (Faker $faker) {
    return [
        //
    ];
});
